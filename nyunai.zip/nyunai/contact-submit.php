<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    // You can add additional validation here if needed

    // Send email (example)
    $to = "your-email@example.com";
    $subject = "New Contact Form Submission";
    $headers = "From: $email";

    // You can customize the email body as per your requirements
    $email_body = "Name: $name\nEmail: $email\n\nMessage:\n$message";

    // Use mail() function to send the email
    if (mail($to, $subject, $email_body, $headers) == false) {
        echo "success";
    } else {
        echo 'Unable to send mail.';
    }
}