<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Nyunai</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Cabin' rel='stylesheet'>

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/styles.css" rel="stylesheet">

</head>

<body>

    <!--==========================
  Header
  ============================-->
    <header id="header">
        <div class="container">

            <div id="logo" class="pull-left">
                <a href="index.php"><img src="img/logo.png" alt="" title=""></img></a>

            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">
                    <li><a href="#hero">News</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#portfolio" class="active">Products</a></li>

                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->

    <!--==========================
    Hero Section
  ============================-->
    <section id="hero">
        <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center">
            <div class="container">
                <div class="row justify-content-start">
                    <div class="col-12 col-lg-5 mb-5">
                        <h1 class="display-3 text-white animated slideInDown mb-4">Making deep<br> learning models <br>
                            <span class="typed-text"></span> <span class="cursor">&nbsp;</span>
                        </h1>
                    </div>
                    <div class="col-12 col-lg-3 "></div>
                    <div class="col-12 col-lg-4 ">
                        <div class="potential ">
                            <p class="mt-5 pt-5">Unleash the true potential of your business through our lean,
                                efficient, and super-fast deep learning
                                models.
                                Whether it's <span> optimizing performance, or accelerating inference speeds, we've got
                                    you covered.

                            </p>
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div id="carouselExampleIndicators" class="carousel slide">
                                            <div class="carousel-indicators">
                                                <button type="button" data-bs-target="#carouselExampleIndicators"
                                                    data-bs-slide-to="0" class="active" aria-current="true"
                                                    aria-label="Slide 1"></button>
                                                <button type="button" data-bs-target="#carouselExampleIndicators"
                                                    data-bs-slide-to="1" aria-label="Slide 2"></button>
                                                <button type="button" data-bs-target="#carouselExampleIndicators"
                                                    data-bs-slide-to="2" aria-label="Slide 3"></button>
                                                <button type="button" data-bs-target="#carouselExampleIndicators"
                                                    data-bs-slide-to="3" aria-label="Slide 4"></button>
                                                <button type="button" data-bs-target="#carouselExampleIndicators"
                                                    data-bs-slide-to="4" aria-label="Slide 5"></button>
                                            </div>
                                            <div class="carousel-inner">
                                                <div class="carousel-item active">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-11">
                                                                <div class="nyunai">
                                                                    <p>“Using the NyunAI platform, we were able to train
                                                                        and deploy our model 2.7B LLM for
                                                                        code
                                                                        generation with our own data within a week and
                                                                        achieve leading results.”</p>
                                                                    <button type="button"
                                                                        class="btn btn-light w-100"><img
                                                                            src="img/g1.png"></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="carousel-item">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-11">
                                                                <div class="nyunai">
                                                                    <p>“Using the NyunAI platform, we were able to train
                                                                        and deploy our model 2.7B LLM for
                                                                        code
                                                                        generation with our own data within a week and
                                                                        achieve leading results.”</p>
                                                                    <button type="button"
                                                                        class="btn btn-light w-100"><img
                                                                            src="img/g1.png"></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="carousel-item">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-11">
                                                                <div class="nyunai">
                                                                    <p>“Using the NyunAI platform, we were able to train
                                                                        and deploy our model 2.7B LLM for
                                                                        code
                                                                        generation with our own data within a week and
                                                                        achieve leading results.”</p>
                                                                    <button type="button"
                                                                        class="btn btn-light w-100"><img
                                                                            src="img/g1.png"></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="carousel-item">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-11">
                                                                <div class="nyunai">
                                                                    <p>“Using the NyunAI platform, we were able to train
                                                                        and deploy our model 2.7B LLM for
                                                                        code
                                                                        generation with our own data within a week and
                                                                        achieve leading results.”</p>
                                                                    <button type="button"
                                                                        class="btn btn-light w-100"><img
                                                                            src="img/g1.png"></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="carousel-item">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-11">
                                                                <div class="nyunai">
                                                                    <p>“Using the NyunAI platform, we were able to train
                                                                        and deploy our model 2.7B LLM for
                                                                        code
                                                                        generation with our own data within a week and
                                                                        achieve leading results.”</p>
                                                                    <button type="button"
                                                                        class="btn btn-light w-100"><img
                                                                            src="img/g1.png"></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <button class="carousel-control-next " type="button"
                                                data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                                <img src="img/icon.png">
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4 Contacts mt-2 wow zoomIn"
                        style="object-fit: cover; visibility: visible; animation-delay: 0.9s; animation-name: zoomIn;">
                        <button type="button" class="btn btn-outline-secondary">Contact Us >> </button>
                    </div>
                    <div class="col-12 col-lg-4">
                    </div>
                    <div class="col-12 col-lg-4">

                    </div>
                </div>
            </div>
        </div>
    </section><!-- #hero -->
    <!-- Services  -->
    <section class="py-5 Services">
        <div class="container mt-4">
            <div class="row ">
                <!--team-1-->
                <div class="col-lg-6  wow bounceInRight float"
                    style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInRight;">
                    <div class="our-team-main">
                        <div class="team-front">
                            <img src="img/icons.png" class="img-fluid" />
                            <h3>Save upto <span>80%</span> on<br>
                                the gpu computing cost </h3>
                        </div>

                        <div class="team-back">
                            <h3>Save upto <span>80%</span> on<br>
                                the gpu computing cost </h3>
                            <p>
                                As DL models become increasingly demanding, we're experts in <br> optimizing them for
                                efficiency,
                                resulting in significant cost savings while <br>maintaining peak performance.

                            </p>
                        </div>

                    </div>
                </div>
                <!--team-1-->

                <!--team-2-->
                <div class="col-lg-6  wow bounceInRight float"
                    style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInRight;">
                    <div class="our-team-main">
                        <div class="team-front">
                            <img src="img/icon-2.png" class="img-fluid" />
                            <h3>Get up to <span> 6x</span> inference <br>
                                speeds on same devices</h3>
                        </div>
                        <div class="team-back">
                            <h3>Get up to <span> 6x</span> inference <br>speeds on same devices</h3>
                            <p>
                                Our deep learning models are engineered for unrivaled inference speeds, <br>enhancing
                                user experiences
                                and enabling seamless follow-up tasks, particularly <br>in critical applications like
                                autonomous driving
                                and object detection.
                        </div>

                    </div>
                </div>
                <!--team-2-->

                <!--team-3-->
                <div class="col-lg-6  wow bounceInLeft float"
                    style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInLeft;">
                    <div class="our-team-main">
                        <div class="team-front">
                            <img src="img/icon-3.png" class="img-fluid" />
                            <h3>Enable powerful DL <br>
                                models on small devices </h3>
                        </div>

                        <div class="team-back">
                            <h3>Enable powerful DL <br>
                                models on small devices</h3>
                            <p>
                                We've mastered the art of making Generative AI models lean and efficient,<br> enabling
                                deployment on
                                mobile devices and bringing the magic of AI to a<br> broader audience.

                            </p>
                        </div>

                    </div>
                </div>
                <!--team-3-->

                <!--team-4-->
                <div class="col-lg-6 wow bounceInLeft float"
                    style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInLeft;">
                    <div class="our-team-main">
                        <div class="team-front">
                            <img src="img/icon-4.png" class="img-fluid" />
                            <h3>Secure your data by <br>
                                switching to edge computing </h3>
                        </div>

                        <div class="team-back">
                            <h3>Secure your data by <br>
                                switching to edge computing </h3>
                            <p>
                                Data privacy and security are non-negotiable. Nyun AI ensures the utmost <br>protection
                                by deploying
                                deep learning models on edge devices, eliminating the <br>need for streaming data on the
                                cloud and
                                ensuring private and secure networks.
                            </p>
                        </div>

                    </div>
                </div>
                <!--team-4-->
            </div>
        </div>
    </section>
    <!-- Services -->
    <section class="zero py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-12 mt-5">
                    <img src="img/image-2.png" class="w-100 wow zoomIn" data-wow-delay="0.1s"
                        style="visibility: visible; animation-delay: 0.1s; animation-name: zoomIn;">
                </div>
                <div class="col-lg-12 text-center zeros pb-4">
                    <img src="img/logo-2.png" class="">
                </div>
                <div class="col-lg-12 text-center mt-5 wow zoomIn" data-wow-delay="0.1s"
                    style="visibility: visible; animation-delay: 0.1s; animation-name: zoomIn;">
                    <h5>Nyun Zero is a No-code, Super user-friendly, 360-degree efficiency AI-driven suite. </h5>
                    <p>Nyun Zero is a No-code, Super user-friendly, 360-degree efficiency AI-driven suite.

                        Nyun Zero provides a seamless and hassle-free entry point to the world of Artificial
                        Intelligence, whether
                        you're a seasoned pro or just starting out. It encompasses multiple frameworks for deep learning
                        models and
                        is flexible in terms of deployment on multiple devices.. You can swiftly implement AI solutions
                        within your
                        organization, empowering your team to leverage the full potential of AI in solving complex
                        problems and
                        driving innovation.
                    </p>

                    <div class="mt-5 wow zoomIn" data-wow-delay="0.1s"
                        style="visibility: visible; animation-delay: 0.1s; animation-name: zoomIn;">
                        <button type="button" class="btn btn-outline-secondary">EXPLORE &nbsp;&nbsp; <img
                                src="img/arrow.png"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="un-lock py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-4 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <img src="img/logo-img.png" class="pb-4">
                    <img src="img/image-4.png" class="w-100">
                </div>
                <div class="col-lg-1">
                </div>
                <div class="col-lg-7 wow bounceInRight float"
                    style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInRight;">
                    <h5>Unlock the full potential of Generative models </h5>
                    <p>Empower Generative models such as Chat GPT, mid journey etc. with the contextual knowledge of
                        your
                        business's terminologies, lingo, industry jargon, quality of customer support,etc.
                        Nyun Adapt simplifies training Generative Models for specific use cases, enabling direct
                        deployment of
                        task-focused models in live environments.</p>
                    <ul>
                        <li>Train LLM for a specific use case </li>
                        <li> Easy to upload data, no-code training </li>
                        <li> Easily deployable through Nyun Zero platform
                        </li>
                    </ul>
                    <div class="mt-5">
                        <button type="button" class="btn btn-primary mt-4">Train Generative Models with Nyun Adapt
                            &nbsp; &nbsp;
                            <img src="img/arrow-1.png" class="live"> <img src="images/a1.svg" class="mt-1 pt-1 lives"></button>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Models -->
    <section class="efficiency"></section>
    <section class="un-lock py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-6 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5>Make your models ultra efficient</h5>
                    <p>Experience the benefits of an efficient models such as computing cost savings, faster inference
                        speeds and
                        ability to deploy large models on small devices.
                        Nyun Kompress leverages cutting-edge model compression techniques, guaranteeing highly efficient
                        and
                        lightning-fast deep-learning models .</p>
                    <ul>
                        <li>Use multiple model compression techniques to make the models fast and efficient.</li>
                        <li> Get Compute efficient and fast deep learning models</li>
                        <li> Easily deployable through Nyun Zero platform</li>
                    </ul>
                    <div class="mt-5">
                        <button type="button" class="btn btn-primary mt-4"> Compress models with Nyun Kompress &nbsp;
                            &nbsp;
                            <img src="img/arrow-1.png"></button>

                    </div>
                </div>
                <div class="col-lg-1"></div>
                <div class="col-lg-5 Compress wow bounceInRight float"
                    style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInRight;">
                    <img src="img/image-5.png" class="w-100">
                </div>
            </div>
        </div>
    </section>
    <section class="efficiency"></section>
    <!-- models -->
    <section class="un-lock py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-4 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <img src="img/image-6.png" class="w-100">
                </div>
                <div class="col-lg-1">
                </div>
                <div class="col-lg-7 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5>All relevant KPIs at your fingertips</h5>
                    <p>Effortlessly monitor deep learning model performance with Nyun Tracker. Gain real-time insights
                        into
                        computing power consumption, memory utilization, latency, precision, and more. Seamlessly
                        integrate the
                        Tracker with any other Nyun product for enhanced insights.</p>
                    <ul>
                        <li>Tracker shows real-time metrics which are relevant for a model.</li>
                        <li>Super easy to deploy.
                        </li>
                    </ul>
                    <div class="mt-5">
                        <button type="button" class="btn btn-primary mt-4 px-5">Monitor with Nyun Tracker &nbsp; &nbsp;
                            <img src="img/arrow-1.png"></button>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="privacy py-5">
        <div class="container mt-3">
            <div class="row">
                <div class="col-lg-3 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;"><img src="img/abc.png"
                        class="w-100"></div>
                <div class="col-lg-1"></div>
                <div class="col-lg-8 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5>Safeguarding your data privacy</h5>
                    <p>At Nyun AI, we deeply value the significance of your data and prioritize its privacy and
                        security, which
                        are paramount for your organization. With this in mind, we take rigorous measures to ensure that
                        your data
                        is masked at every point, safeguarding it from any potential vulnerabilities. Moreover, we offer
                        the
                        flexibility of deploying our tools on user servers, granting you complete control and ownership
                        of your
                        data. Rest assured, your data remains solely with you, reinforcing our commitment to maintaining
                        its
                        confidentiality and protection.</p>
                    <div class="text-end">
                        <button type="button" class="btn btn-outline-secondary">Read our privacy policy &nbsp; &nbsp;
                            <img src="img/arrow-2.png"></button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="journey py-5 ">
        <div class="container pb-5">
            <div class="row">
                <div class="col-lg-12 deep py-5 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h4>Ready to Embark on your AI journey?</h4>
                    <p>Unveil the possibilities of streamlined, efficient, and lightning-fast deep learning models with
                        Nyun AI.
                        Together, let's shape a sustainable and potent AI future. Reach out to our team today to delve
                        into how our
                        solutions can revolutionize your business.
                    </p>
                    <div class="mt-5 wow zoomIn" data-wow-delay="0.3s"
                        style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                        <button type="button" class="btn btn-success px-5">&nbsp;&nbsp; Schedule a Call
                            &nbsp;&nbsp;</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="bg-dark text-white  text-lg-start py-5">
        <!-- Grid container -->
        <div class="container p-4">
            <!--Grid row-->
            <div class="row">
                <!--Grid column-->
                <div class="col-lg-4 col-md-12 mb-4 mb-md-0 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <img src="img/logo-2.png" class="w-100 pb-5">
                    <p class="mt-4 pb-2">The trailblazers in unleashing the true potential of your business through our
                        cutting-edge AI solutions
                        using lean, efficient, and super-fast deep learning models</p>
                    <span>© nyunai private limited. All rights reserved.</span>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-2 col-md-6 mb-4 mb-md-0 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5 class="text-uppercase">QUICK LINKS</h5>

                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="#!" class="text-white">Support</a>
                        </li>

                        <li>
                            <a href="#!" class="text-white"> Demo</a>
                        </li>

                        <li>
                            <a href="#!" class="text-white"> About</a>
                        </li>

                        <li>
                            <a href="#!" class="text-white"> News</a>
                        </li>

                        <li>
                            <a href="#!" class="text-white"> Services</a>
                        </li>

                        <li>
                            <a href="#!" class="text-white"> Products</a>
                        </li>

                    </ul>
                </div>
                <!--Grid column-->
                <div class="col-lg-2 col-md-6 mb-4 mb-md-0 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5 class="text-uppercase">PRODUCTS</h5>

                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="#!" class="text-white">Nyun zero</a>
                        </li>

                        <li>
                            <a href="#!" class="text-white"> Nyun Adapt</a>
                        </li>

                        <li>
                            <a href="#!" class="text-white"> Nyun Kompress</a>
                        </li>

                        <li>
                            <a href="#!" class="text-white"> Nyun Track</a>
                        </li>


                        <li>
                            <a href="#!" class="text-white"> Products</a>
                        </li>

                    </ul>
                </div>
                <!--Grid column-->
                <div class="col-lg-2 col-md-6 mb-4 mb-md-0 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5 class="text-uppercase mb-4">SOCIAL</h5>

                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="#!" class="text-white">Linkedin

                            </a>
                        </li>
                        <li>
                            <a href="#!" class="text-white"> Twitter
                            </a>
                        </li>
                        <li>
                            <a href="#!" class="text-white"> Medium</a>
                        </li>

                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase mb-4">CONTACT</h5>


                    <p>+9876543210</p>


                    <p>Address Lorem Ipsum
                        Lorem ipsum</p>


                    </ul>
                </div>
                <!--Grid column-->
            </div>
            <!--Grid row-->
        </div>
        <!-- Grid container -->


    </footer>
    <!-- Social Icons Start-->
    <div class="sticky-social">
        <ul class="social">
            <li class="fb"><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            <li class="insta"><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>

            <li class="twitter"><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>

        </ul>
    </div>
    <!-- Social Icons End -->

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/jquery/jquery-migrate.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/superfish/superfish.min.js"></script>

    <script src="js/main.js"></script>

</body>

</html>
<script>
    const typedTextSpan = document.querySelector(".typed-text");
    const cursorSpan = document.querySelector(".cursor");

    const textArray = ["Lean", "Efficient", "Faster", "Affordable", "Sustainable"];
    const typingDelay = 100;
    const erasingDelay = 100;
    const newTextDelay = 100; // Delay between current and next text
    let textArrayIndex = 0;
    let charIndex = 0;

    function type() {
        if (charIndex < textArray[textArrayIndex].length) {
            if (!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
            typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
            charIndex++;
            setTimeout(type, typingDelay);
        }
        else {
            cursorSpan.classList.remove("typing");
            setTimeout(erase, newTextDelay);
        }
    }

    function erase() {
        if (charIndex > 0) {
            if (!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
            typedTextSpan.textContent = textArray[textArrayIndex].substring(0, charIndex - 1);
            charIndex--;
            setTimeout(erase, erasingDelay);
        }
        else {
            cursorSpan.classList.remove("typing");
            textArrayIndex++;
            if (textArrayIndex >= textArray.length) textArrayIndex = 0;
            setTimeout(type, typingDelay + 2100);
        }
    }

    document.addEventListener("DOMContentLoaded", function () { // On DOM Load initiate the effect
        if (textArray.length) setTimeout(type, newTextDelay + 250);
    });
</script>