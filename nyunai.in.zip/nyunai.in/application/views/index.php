<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Nyunai</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <link rel="icon" type="image/x-icon" href="<?php echo base_url();?>assets/images/favicon.png">

    <!-- Favicons -->
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Cabin' rel='stylesheet'>

    <!-- Bootstrap CSS File -->
    <link href="<?php echo base_url();?>assets/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="<?php echo base_url();?>assets/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/lib/animate/animate.min.css" rel="stylesheet">
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
    <!-- Main Stylesheet File -->
    <link href="<?php echo base_url();?>assets/css/stylecs.css" rel="stylesheet">
    <style>
        @media only screen and (max-width: 600px) {

            #hero .btn-outline-secondary {
                color: #FFF;
                background-color: transparent;
                background-image: none;
                border-color: #fff;
                padding: 12px 62px 12px;
                font-size: 17px;
                font-weight: 500;
                border: 3px solid;
                border-radius: 2px;
                width: 79% !important;
                margin-top: 119px;
            }

            #hero {
                width: 100%;
                height: 200vh;
                background-image: url(assets/images/banner-1.png);
                background-size: cover;
                position: relative;
            }

            .safeguarding {
                text-align: center;
            }
        }
        .carousel-indicators [data-bs-target] {
    box-sizing: content-box;
    flex: 0 1 auto;
    width: 8px;
    height: 9px;}
    .feature-list {
    display: flex;
    flex-wrap: wrap;
    list-style: none;
    padding: 0;
}

.feature-list li {
    flex: 1;
    margin: 16px;
    text-align: left;
}

.white-text {
    color: #dbdbdb;
    line-height: 1.4;
    font-size: 12px;/* Sets the white color with 80% opacity (#80) */
}
p {
    font-size: 16px; /* Adjust the value as needed to increase the text size */
}
    </style>
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-V2HJ2YR57S"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-V2HJ2YR57S');
</script>
</head>

<body>

    <!--==========================
  Header
  ============================-->
   <?php $this->load->view('includes/header');?>
    <!--==========================
    Hero Section
  ============================-->
  <section class="banners py-5">
  </section><section class="banners py-5">
    </section>
    <section class="banners py-5">
        <div class="container  pt-4">
            <div class="row">
                <div class="col-lg-5 col-sm-4 col-md-4">
                    <h1 class="display-3 text-white animated slideInDown mb-4">Making deep<br> learning models <br>
                        <span id="flipper" class="flip">
                            <span class="step step0 set">Lean</span>
                            <span class="step step1">Efficient</span>
                            <span class="step step2">Faster</span>
                            <span class="step step3">Affordable</span>
                            <span class="step step4 down">Sustainable</span>

                        </span>
                    </h1>
                    <div class="ctn">
                            <a href="<?php echo base_url('contact');?>" type="button" class="btn btn-outline-secondary w-50">Contact Us &gt;&gt;
                            </a>

                        </div>
                </div>
                <div class="col-lg-3 col-sm-4 col-md-4 cover">
                    <img src="<?php echo base_url();?>assets/images/img.png" class="w-100">
                </div>
                <div class="col-sm-4 col-md-4  col-lg-4 ">
                        <div class=" ">
                            <p class=" pt-2">Unleash the true potential of your business through our lean,
                                efficient, and super-fast deep learning
                                models.
                                Whether it's <span> optimizing performance, or accelerating inference speeds, we've got
                                    you covered.

                            </span></p>
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12 col-sm-12 col-md-12">
                                        <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
                                            <div class="carousel-indicators">
                                                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-label="Slide 1" aria-current="true"></button>
                                                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
                                                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3" class=""></button>
                                                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="3" aria-label="Slide 4" class=""></button>
                                                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="4" aria-label="Slide 5"></button>
                                            </div>
                                            <div class="carousel-inner">
                                                <div class="carousel-item active">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-11">
                                                                <div class="nyunai">
                                                                    <p>Developing the state-of-the-art (SOTA) model
                                                                        pruning method, called chipnet, <span>ICLR
                                                                            2021</span>
                                                                    </p>
                                                                    <button type="button" class="btn btn-light w-100"><img src="<?php echo base_url();?>assets/images/icrl.svg"></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="carousel-item">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-11">
                                                                <div class="nyunai">
                                                                    <p>Improving the generalization ability &amp;
                                                                        efficiency
                                                                        of AI metamodels with metadock, <span>CVPR
                                                                            2022</span>
                                                                    </p>
                                                                    <button type="button" class="btn btn-light w-100"><img src="<?php echo base_url();?>assets/images/cvpr.png"></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="carousel-item">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-11">
                                                                <div class="nyunai">
                                                                    <p>Training CNNs on very large images using a single
                                                                        GPU, a task that was previously impossible, with
                                                                        patchGD, <span>NeurIPS 2023*</span></p>
                                                                    <button type="button" class="btn btn-light w-100"><img src="<?php echo base_url();?>assets/images/ne1.png"></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="carousel-item">
                                                    <div class="container">
                                                        <div class="row">
                                                            <div class="col-lg-11">
                                                                <div class="nyunai">
                                                                    <p>Glora, the best way to design large models with
                                                                        inexpensive computers, <span>NeurIPS
                                                                            2023*</span>
                                                                    </p>
                                                                    <button type="button" class="btn btn-light w-100"><img src="<?php echo base_url();?>assets/images/ne1.png"></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>
                                            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                                                <img src="<?php echo base_url();?>assets/images/icon.png">
                                            </button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </section>
    <!-- Services  -->
    <section class="py-5 Services">
        <div class="container">
            <div class="section ourTeam">

                <div class="row">
                    <div class="col-lg-6 col-sm-6  col-md-6 i save">
                        <div class="abc">
                            <div class="c text-center">
                                <div class="wrap pb-3">
                                    <img src="<?php echo base_url();?>assets/images/icon1.svg" class="img-fluid">
                                    <div class="info mt-3">
                                        <h4 class="position">Save upto <span>80%</span> on<br>
                                            the gpu computing cost </h4>
                                    </div>
                                </div>
                                <div class="more">

                                    <p>As DL models become increasingly demanding, we're experts<br> in optimizing them
                                        for efficiency, resulting in significant cost savings while <br> maintaining
                                        peak performance.</p>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6  col-md-6 i  ">
                        <div class="abc">
                            <div class="c text-center">
                                <div class="wrap pb-3">
                                    <img src="<?php echo base_url();?>assets/images/icon-2.svg" class="img-fluid">
                                    <div class="info">
                                        <h4 class="position ml-4">Get up to <span>6x</span> inference<br>
                                            speeds on same devices </h4>
                                    </div>
                                </div>
                                <div class="more">
                                    <p>Our deep learning models are engineered for unrivaled inference speeds,<br>
                                        enhancing
                                        user experiences and enabling seamless follow-up tasks, particularly<br> in
                                        critical
                                        applications like autonomous driving and object detection.</p>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6  col-md-6 i  ">
                        <div class="abc">
                            <div class="c text-center">
                                <div class="wrap">
                                    <img src="<?php echo base_url();?>assets/images/icon-3.svg" class="img-fluid" style="width: 21%;">
                                    <div class="info">
                                        <h4 class="position mr-4">Enable powerful DL <br>
                                            models on small devices </h4>
                                    </div>
                                </div>
                                <div class="more mores">
                                    <p>We've mastered the art of making Generative AI models lean and efficient,<br>
                                        enabling deployment on mobile devices and bringing the magic of AI to a
                                        <br>broader
                                        audience.
                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6  col-md-6 i">
                        <div class="abc">
                            <div class="c d text-center">
                                <div class="wrap mt-4">
                                    <img src="<?php echo base_url();?>assets/images/icon-6.png" class="img-fluid pb-5" style="width:55%;">
                                    <div class="info ">
                                        <h4 class="position">Secure your data by <br>
                                            switching to edge computing </h4>
                                    </div>
                                </div>
                                <div class="moress">
                                    <p>Data privacy and security are non-negotiable. Nyun AI ensures the utmost<br>
                                        protection by deploying deep learning models on edge devices, eliminating the
                                        <br>need for streaming data on the cloud and ensuring private and secure
                                        networks.
                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Services -->
    <section id="nyunaizero" class="zero py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-12 mt-5">
                    <img src="<?php echo base_url();?>assets/images/image-2.svg" class="w-100 wow zoomIn" data-wow-delay="0.1s"
                        style="visibility: visible; animation-delay: 0.1s; animation-name: zoomIn;">
                </div>
                <div class="col-lg-12 text-center zeros pb-4">
                    <img src="<?php echo base_url();?>assets/images/1.svg" class="">
                </div>
                <div class="col-lg-12 text-center mt-5 wow zoomIn" data-wow-delay="0.1s"
                    style="visibility: visible; animation-delay: 0.1s; animation-name: zoomIn;">
                    <h5 style="font-size: 28px">Discover the Future of AI Efficiency with Nyun Zero</h5>
                    <p>Nyun Zero is more than just an AI-driven suite; it's your key to unlocking the limitless possibilities of Artificial Intelligence on a tight budget. Whether you're a seasoned pro or just embarking on your AI journey, Nyun Zero is your no-code, super user-friendly companion that redefines AI efficiency from every angle.
                    </p>
                    <br><br>
<h4 style="color: white;">Why Choose Nyun Zero?</h4>
    <ul class="feature-list">
    <li>
        <h6><strong>No-Code, Super User-Friendly:</strong></h6>
        <p class="white-text">Bid farewell to complex coding and embrace a seamless AI experience. Nyun Zero's intuitive interface ensures that AI is accessible to everyone, regardless of your expertise.</p>
    </li>
    <li>
        <h6><strong>360-Degree Efficiency:</strong></h6>
        <p class="white-text">Nyun Zero is engineered for efficiency at every turn. From training to deployment, it covers all bases, optimizing performance and resource utilization.</p>
    </li>
    <li>
        <h6><strong>Versatile Frameworks:</strong></h6>
        <p class="white-text">With support for multiple deep learning frameworks, Nyun Zero allows you to work with the tools and technologies that best suit your needs.</p>
    </li>
    <li>
        <h6><strong>Device Flexibility:</strong></h6>
        <p class="white-text">Nyun Zero's adaptability allows deployment across various devices, breaking down barriers and ensuring AI solutions seamlessly integrate with your organization's infrastructure.</p>
    </li>
    <li>
        <h6><strong>Empower Your Team:</strong></h6>
        <p class="white-text">Nyun Zero enables rapid implementation of AI solutions within your organization. Empower your team to harness AI's full potential, tackling complex challenges and driving innovation like never before.</p>
    </li>
</ul>

                    <div class="mt-5 wow zoomIn complex" data-wow-delay="0.1s"
                        style="visibility: visible; animation-delay: 0.1s; animation-name: zoomIn;">
                        <button type="button" class="btn btn-outline-secondary" onclick="javascript:window.location='<?php echo base_url();?>nyunzero'">EXPLORE
                            &nbsp;&nbsp; <img src="<?php echo base_url();?>assets/images/arrow.png" class="explore"><img src="<?php echo base_url();?>assets/images/arrow-1.png"
                                class="explores">

                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="nyunadapt" class="un-lock py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-sm-4 col-md-4 col-lg-4 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <img src="<?php echo base_url();?>assets/images/logo-img.png" class="pb-4 w-100">
                    <img src="<?php echo base_url();?>assets/images/nyun_adapt_illustration.svg" class="w-100">
                </div>
                <div class="col-lg-1 col-sm-1 col-md-1">
                </div>
                <div class="col-sm-7 col-md-7 col-lg-7 wow bounceInRight float"
                    style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInRight;">
                    <h5>Unleash the Power of Generative Models on a Budget</h5>
                    <p>Experience the full potential of Generative models without breaking the bank. Nyun Adapt is your cost-effective solution to empower models like GPT and DALL-E with the contextual knowledge of your business's unique terminologies, lingo, industry-specific jargon, and customer support excellence. Our platform simplifies the training of Generative Models for specific use cases, enabling seamless deployment in live environments, all while keeping costs down.</p>
                    <ul>
                        <li>Tailored & Efficient LLM Fine-Tuning, Affordable Rates</li>
                        <li> Easy Data Upload While Preserving Privacy </li>
                        <li> Efficient Deployment with Nyun Zero
                        </li>
                    </ul>
                    <div class="mt-5">
                        <button type="button" class="btn btn-primary mt-4" onclick="javascript:window.location='<?php echo base_url();?>nyunadapt'">Train Generative Models with Nyun Adapt
                            &nbsp; &nbsp;
                            <img src="<?php echo base_url();?>assets/images/arrow-1.png" class="explore"></button>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Models -->
    <section class="efficiency"></section>
    <section id="nyunkompress" class="un-lock svings py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5>Unlock Peak Efficiency with Nyun Kompress</h5>
                    <p>Discover the advantages of ultra-efficient models, including substantial computing cost savings, lightning-fast inference speeds, and the capability to deploy extensive models even on compact devices. Nyun Kompress harnesses state-of-the-art model compression techniques, ensuring that your deep-learning models are exceptionally efficient and perform at their best.</p>
                    <ul>
                        <li>A Symphony of Advanced Model Compression Algorithms</li>
                        <li> Superior Efficiency, Accelerated Models, Lower Costs</li>
                        <li> Seamless Hardware-aware Deployment with Nyun Zero</li>
                    </ul>
                    <div class="mt-5">
                        <button type="button" class="btn btn-primary mt-4" onclick="javascript:window.location='<?php echo base_url();?>nyunkompress'"> Compress models with Nyun Kompress
                            &nbsp; &nbsp;
                            <img src="<?php echo base_url();?>assets/images/arrow-1.png" class="explore"> </button>

                    </div>
                </div>
                <div class="col-lg-1 col-md-1 co-sm-0 smalls"></div>
                <div class="col-lg-5 col-sm-5 col-md-5 Compress wow bounceInRight float"
                    style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInRight;">
                    <img src="<?php echo base_url();?>assets/images/compressd.png" class="w-100">
                    <img src="<?php echo base_url();?>assets/images/nyun_kompress_illustration.svg" class="w-100">
                </div>
            </div>
        </div>
    </section>
    <!-- mobile -->
    <section class="un-lock  mobile pb-5">
        <div class="container ">
            <div class="row">

                <div class="col-lg-5 col-md-5 col-sm-5 Compress wow bounceInRight float"
                    style="visibility: visible; animation-delay: 0.2s; animation-name: bounceInRight;">
                    <img src="<?php echo base_url();?>assets/images/compress.svg" class="w-100">
                    <img src="<?php echo base_url();?>assets/images/nyun_kompress_illustration.svg" class="w-100">
                </div>
                <div class="col-lg-1 col-md-1 col-sm-1 smalls"></div>
                <div class="col-lg-6 col-md-6 col-sm-6 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5>Unlock Peak Efficiency with Nyun Kompress</h5>
                    <p>Discover the advantages of ultra-efficient models, including substantial computing cost savings, lightning-fast inference speeds, and the capability to deploy extensive models even on compact devices. Nyun Kompress harnesses state-of-the-art model compression techniques, ensuring that your deep-learning models are exceptionally efficient and perform at their best.</p>
                    <ul>
                        <li>A Symphony of Advanced Model Compression Algorithms</li>
                        <li> Superior Efficiency, Accelerated Models, Lower Costs</li>
                        <li> Seamless Hardware-aware Deployment with Nyun Zero</li>
                    </ul>
                    <div class="mt-5">
                        <button type="button" class="btn btn-primary mt-4" onclick="javascript:window.location='<?php echo base_url();?>nyunkompress'"> Compress models with Nyun Kompress
                            &nbsp; &nbsp;
                            <img src="<?php echo base_url();?>assets/images/arrow-1.png" class="explore"> </button>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- mobile -->
    <section class="efficiency"></section>

    <section id="ntrack" class="un-lock py-5">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-4 col-sm-4 col-md-4 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <img src="<?php echo base_url();?>assets/images/track_logo.svg" class="w-100">
                    <img src="<?php echo base_url();?>assets/images/nyun_track_illustration.svg" class="w-100">

                </div>
                <div class="col-lg-1 col-sm-1 col-md-1">
                </div>
                <div class="col-lg-7 col-sm-7 col-md-7 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5>All relevant KPIs at your fingertips</h5>
                    <p>Keep your finger on the pulse of your deep learning model's performance effortlessly with Nyun Tracker. Gain real-time access to crucial model stats such as computing power consumption, memory utilization, latency, precision, and more. Seamlessly integrate the Tracker with any other Nyun product for enhanced insights that drive informed decisions.</p>
                    <ul>
                        <li>Real-Time, Relevant Metrics</li>
                        <li>Super easy to deploy.
                        </li>
                    </ul>
                    <div class="mt-5">
                        <button type="button" class="btn btn-primary mt-4" onclick="javascript:window.location='<?php echo base_url();?>nyuntrack'">Monitor with Nyun Tracker

                            &nbsp; &nbsp; &nbsp;
                            <img src="<?php echo base_url();?>assets/images/arrow-1.png" class="explore"></button>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Mobile View -->
    <section class="privacy py-5">
        <div class="container mt-3">
            <div class="row">
                <div class="col-sm-3 col-md-3 col-lg-3 safeguarding"><img src="<?php echo base_url();?>assets/images/abc.png" class="w-100"></div>
                <div class="col-lg-1 col-sm-1 col-md-1"></div>
                <div class="col-lg-8 col-sm-8 col-sm-8">
                    <h5>Safeguarding your data privacy</h5>
                    <p>At Nyun AI, we deeply value the significance of your data and prioritize its privacy and
                        security, which
                        are paramount for your organization. With this in mind, we take rigorous measures to ensure that
                        your data
                        is masked at every point, safeguarding it from any potential vulnerabilities. Moreover, we offer
                        the
                        flexibility of deploying our tools on user servers, granting you complete control and ownership
                        of your
                        data. Rest assured, your data remains solely with you, reinforcing our commitment to maintaining
                        its
                        confidentiality and protection.</p>
                    <div class="text-end">
                        <button type="button" class="btn btn-outline-secondary">Read our privacy policy
                            &nbsp;&nbsp; <img src="<?php echo base_url();?>assets/images/arrow.png" class="explore"> <img src="<?php echo base_url();?>assets/images/arrow-1.png"
                                class="explores">

                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="journey py-5 ">
        <div class="container pb-5">
            <div class="row">
                <div class="col-lg-12 deep py-5">
                    <h4>Ready to Embark on your AI journey?</h4>
                    <p>Unveil the possibilities of streamlined, efficient, and lightning-fast deep learning models with
                        Nyun AI.
                        Together, let's shape a sustainable and potent AI future. Reach out to our team today to delve
                        into how our
                        solutions can revolutionize your business.
                    </p>
                    <div class="mt-5">
                    <a href="<?php echo base_url('contact');?>"> <button Developing type="button"  class="btn btn-success px-5">&nbsp;&nbsp; Schedule a Call
                            &nbsp;&nbsp;</button></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
   <!-- footer start-->
   <?php $this->load->view('includes/footer');?>
   <!-- footer end -->
    <!-- Social Icons Start-->
    <div class="sticky-social">
        <ul class="social">
            <li class="fb"><a href="#" class="text-dark"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
            <li class="insta"><a href="#" class="text-dark"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>

            <li class="twitter"><a href="#" class="text-dark"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>

        </ul>
    </div>
    <!-- Social Icons End -->

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="<?php echo base_url();?>assets/lib/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/lib/jquery/jquery-migrate.min.js"></script>
    <script src="<?php echo base_url();?>assets/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url();?>assets/lib/easing/easing.min.js"></script>
    <script src="<?php echo base_url();?>assets/lib/wow/wow.min.js"></script>
    <script src="<?php echo base_url();?>assets/lib/counterup/counterup.min.js"></script>
    <script src="<?php echo base_url();?>assets/lib/superfish/superfish.min.js"></script>

    <script src="<?php echo base_url();?>assets/js/main.js"></script>

</body>

</html>

<script>
    (function () {
        var Flip;

        Flip = class Flip {
            constructor(el) {
                this.el = el;
                this.el = $(this.el);
                this.currentStep = 0;
                console.log("Created new Flip");
                $('.next').on('click', $.proxy(this.next, this));
            }

            next(event) {
                var currentStepEl, nextStepEl, nextStepNum;
                if (event) {
                    event.preventDefault();
                }
                nextStepNum = this.currentStep + 1;
                currentStepEl = this.el.find(`.step${this.currentStep}`);
                nextStepEl = this.el.find(`.step${nextStepNum}`);
                if (nextStepEl.length) {
                    console.log('we found the next step', nextStepEl);
                    currentStepEl.prev().removeClass('down');
                    currentStepEl.removeClass('set');
                    currentStepEl.addClass('down');
                    nextStepEl.addClass('set');
                    nextStepEl.removeClass('down');
                    nextStepEl.next().removeClass('down');
                    return this.currentStep++;
                } else {
                    // reset to 0
                    this.el.find(".step").removeClass('set');
                    this.el.find(`.step${this.currentStep}`).addClass('down');
                    this.el.find(".step").not(`.step${this.currentStep}`).removeClass('down');
                    this.currentStep = -1;
                    return this.next();
                }
            }
        };



        $(function () {
            var f;
            f = new Flip(document.getElementById('flipper'));
            return setInterval(function () {
                return f.next();
            }, 1500);
        });

    }).call(this);

//# sourceURL=coffeescript
</script>
<script>

</script>