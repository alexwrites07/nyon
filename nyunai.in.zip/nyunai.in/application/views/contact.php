<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Nyunai</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <link rel="icon" type="image/x-icon" href="<?php echo base_url();?>assets/images/favicon.png">

    <!-- Favicons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Cabin' rel='stylesheet'>

    <!-- Bootstrap CSS File -->
    <link href="<?php echo base_url();?>assets/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="<?php echo base_url();?>assets/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/lib/animate/animate.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
<link href="<?php echo base_url();?>assets/css/stylecs.css" rel="stylesheet">
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-V2HJ2YR57S"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-V2HJ2YR57S');
</script>
</head>
<style>
   .btn-info:hover {
    border-radius: 2px;
    font-size: 18px;
    font-weight: 600 !important;
    border: 1px solid;
    padding: 14px 96px;
    box-shadow: 12px 14px #424242;
    width: 100%;

}
</style>

<body>

    <!--==========================
  Header
  ============================-->
  <?php $this->load->view('includes/header');?>
    <section class="contact-us py-5"></section>
    <section class="contact-us py-3"></section>
    <section class="contact-us py-5 ">
        <div class="container pb-5">
            <div class="row pb-5">
                <div class="col-lg-1"></div>
                <div class="col-lg-5 mt-5 pt-3">
                    <h2>Let’s Talk</h2>
                    <p>Have interest in bringing the power of AI to your business? Then reach out we'd love to hear
                        about your business and your requirements.</p>
                    <div class="mt-5">
                        <h4>Email</h4>
                        <span>contact@nyunai.com</span>

                    </div>
                    <div class="mt-5">
                        <h4>Socials</h4>
                        <span><a href="">Instagram</a></span><br>
                        <span><a href="">Twitter</a></span><br>
                        <span><a href="">Facebook</a></span>

                    </div>
                </div>
                <div class="col-lg-1"></div>
                <div class="col-lg-5">
                    <form>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Name</label>
                            <input type="text" class="form-control" name="sname" id="sname" aria-describedby="emailHelp"
                                placeholder="">

                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Email</label>
                            <input type="email" class="form-control" name="semail" id="semail" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">What service are you interested in</label>
                            <input type="text" class="form-control" id="interested" name="interested"
                                placeholder="Select project type">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Budget</label>
                            <input type="text" class="form-control" id="budget" name="budget"
                                placeholder="Select project budget">
                        </div>
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="3"
                                style="height: 135px;"></textarea>
                        </div>
                        <div class="mt-4">
                            <button type="button" class="btn btn-info w-100 p-2" onclick="submit_query();">Submit</button>
                            <p id="result" class="text-center p-2"></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <?php $this->load->view('includes/footer');?>
</body>

</html>
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script>
    function submit_query() {
        var flag = 0;
        var name = $('#sname').val(); var email = $('#semail').val();var intrested = $('#interested').val();
        var budget = $('#budget').val();
        var message = $('#message').val();
        if (name == "") {
            flag = 1;
            $('#sname').css('border', '1px solid red');
        }
        else{
            $('#sname').css('border', '');
        }
        if (email == "") {
            flag = 1;
            $('#semail').css('border', '1px solid red');
        }
        else{
            $('#semail').css('border', '');
        }
        if (intrested == "") {
            flag = 1;
            $('#interested').css('border', '1px solid red');
        }
        else{
            $('#interested').css('border', '');
        }
        if (budget == "") {
            flag = 1;
            $('#budget').css('border', '1px solid red');
        }
        else{
            $('#budget').css('border', '');
        }
        if (message == "") {
            flag = 1;
            $('#message').css('border', '1px solid red');
        }
        else{
            $('#message').css('border', '');
        }
        if (flag == 0) {
            $("#result").html("<span style='color:green'>Please wait...</span>");
            $.ajax({
                type: "POST",
                url: "<?php echo base_url(); ?>sendmail/send_enquiry_email",
                data: "name=" + name + "&email=" + email + "&interested=" + intrested + "&budget=" + budget + "&message1=" + message,
                cache: false,
                success: function (data) {
                    if (data == "success") {
                        $("#result").html("<span style='color:green'>Your query posted successfully.</span>");
                        $("#sname").val(''); $("#semail").val(''); $("#interested").val(''); $("#budget").val(''); $("#message").val('');
                    } else {
                        $("#result").html("<span style='color:red'>" + data + "</span>");
                    }
                }
            });
        }
    }
</script>