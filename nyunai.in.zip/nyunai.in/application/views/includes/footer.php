<footer class="bg-dark text-white  text-lg-start py-5">
        <!-- Grid container -->
        <div class="container p-4">
            <!--Grid row-->
            <div class="row">
                <!--Grid column-->
                <div class="col-lg-4 col-md-4 col-sm-4 mb-4 mb-md-0 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <img src="<?php echo base_url();?>assets/images/footer-logo.svg" class="w-100 pb-5">
                    <p class="mt-4 pb-2">The trailblazers in unleashing the true potential of your business through our
                        cutting-edge AI solutions
                        using lean, efficient, and super-fast deep learning models</p>
                    <span class="copy">© nyunai private limited. All rights reserved.</span>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-sm-4 col-md-4 col-lg-2 mb-4 mb-md-0 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5 class="text-uppercase">QUICK LINKS</h5>

                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="#!" class="">Support</a>
                        </li>

                        <li>
                            <a href="#!" class=""> Demo</a>
                        </li>

                        <li>
                            <a href="#!" class=""> About</a>
                        </li>


                        <li>
                            <a href="#!" class=""> Services</a>
                        </li>

                        <li>
                            <a href="#!" class=""> Products</a>
                        </li>

                    </ul>
                </div>
                <!--Grid column-->
                <div class="col-sm-4 col-md-4 col-lg-2 mb-4 mb-md-0 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5 class="text-uppercase">PRODUCTS</h5>

                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="<?php echo base_url();?>nyunzero" class="">nyunzero</a>
                        </li>

                        <li>
                            <a href="<?php echo base_url();?>nyunadapt" class=""> nyunadapt</a>
                        </li>

                        <li>
                            <a href="<?php echo base_url();?>nyunkompress" class=""> nyunkompress</a>
                        </li>

                        <li>
                            <a href="<?php echo base_url();?>nyuntrack" class=""> nyuntrack</a>
                        </li>




                    </ul>
                </div>
                <!--Grid column-->
                <div class="col-sm-4 col-md-4 col-lg-2 mb-4 mb-md-0 wow zoomIn" data-wow-delay="0.3s"
                    style="visibility: visible; animation-delay: 0.3s; animation-name: zoomIn;">
                    <h5 class="text-uppercase mb-4">SOCIAL</h5>

                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="#!" class="">Linkedin

                            </a>
                        </li>
                        <li>
                            <a href="#!" class=""> Twitter
                            </a>
                        </li>
                        <li>
                            <a href="#!" class=""> Medium</a>
                        </li>

                    </ul>
                </div>
                <div class="col-sm-4 col-md-4 col-lg-2 mb-4 mb-md-0">
                    <h5 class="text-uppercase mb-4">CONTACT</h5>

                    <p>contact@nyunai.com</p>


                    </ul>
                </div>
                <div class="col-lg-12">
                    <span class="copys">© nyunai private limited. All rights reserved.</span>

                </div>
                <!--Grid column-->
            </div>
            <!--Grid row-->
        </div>
        <!-- Grid container -->


    </footer>