<header id="header">
        <div class="container">

            <div id="logo" class="pull-left">
                <a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>assets/images/logo.png" alt="" title=""></img></a>

            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu sf-js-enabled sf-arrows" style="touch-action: pan-y;">
                    <li class="menu-has-children"><a href="javascript:void(0)" class="sf-with-ul">Products</a>
                        <ul class="bg-dark" style="display: none;">
                         <li><a href="#nyunaizero">N-zero</a></li>
                            <li><a href="#nyunkompress">N-kompress</a></li>
                            <li><a href="#nyunadapt">N-adapt</a></li>
                            <li><a href="#ntrack">N-track</a></li>

                        </ul>
                    </li>
                    <li class="menu-has-children"><a href="javascript:void(0)" class="sf-with-ul">Services</a>
                        <ul style="display: none;">
                            <li><a href="<?php echo base_url('contact');?>">Developing use case-specific models</a></li>
                            <li><a href="<?php echo base_url('contact');?>">Compressing your existing Models</a></li>
                            <li><a href="<?php echo base_url('contact');?>">Training LLMs on your data</a></li>
                            <li><a href="<?php echo base_url('contact');?>">Improving Inference speeds</a></li>
                            <li><a href="<?php echo base_url('contact');?>">Enabling to switch from cloud to edge</a></li>
                        </ul>
                    </li>
                    <li><a href="#about">About Us</a></li>
                    <li><a href="<?php echo base_url('contact');?>">Contact Us</a></li>

                </ul>
            </nav>
        </div>
    </header><!-- #header -->
