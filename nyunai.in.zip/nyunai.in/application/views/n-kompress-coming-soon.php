<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Nyunai</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <link rel="icon" type="image/x-icon" href="<?php echo base_url();?>assets/images/favicon.png">

    <!-- Favicons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Cabin' rel='stylesheet'>

    <!-- Bootstrap CSS File -->
    <link href="<?php echo base_url();?>assets/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="<?php echo base_url();?>assets/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/lib/animate/animate.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="<?php echo base_url();?>assets/css/stylecs.css" rel="stylesheet">
    <style>
        .btn-outline-secondary:hover {
            padding: 12px 62px 12px;
            font-size: 17px;
            font-weight: 500;
            border: 3px solid;
            border-radius: 25px;
        }
    </style>

</head>

<body>

    <!--==========================
  Header
  ============================-->
  <?php $this->load->view('includes/header');?>

    <section class="coming-soon py-5 pt-5 mt-5">
        <div class="container pb-5">
            <div class="row text-center mt-5">
                <div class="col-lg-12 soon py-5">
                    <img src="<?php echo base_url();?>assets/images/load-bar.png" class="w-5">
                    <h5>Coming Soon</h5>
                    <p>Launching November’23</p>
                </div>
                <div class="col-lg-12 mt-3">
                    <img src="<?php echo base_url();?>assets/images/compressd.png" class="w-50">
                </div>
                <div class="col-lg-12">
                    <h4>Make your models ultra efficient </h4>
                    <p>Experience the benefits of an efficient models such as computing cost savings, faster inference speeds and ability to deploy large models on small devices. Nyun Kompress leverages cutting-edge model compression techniques, guaranteeing highly efficient and lightning-fast deep-learning models .</p>
                </div>

                <div class="col-lg-12">
                    <ul>
                        <li> <span>.</span> Use multiple model compression techniques to make the models fast and efficient.</li>
                        <li> <span>.</span> Get Compute efficient and fast deep learning models</li>
                        <li> <span>.</span> Easily deployable through Nyun Zero platform</li>
                    </ul>
                </div>

            </div>
        </div>
        <div class="container Easy py-5 mb-5">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-4 text-end mt-3">
                    <h5>Want to deploy today?</h5>
                </div>
                <div class="col-lg-4">
                    <button type="button" class="btn btn-outline-secondary" onclick="javascript:window.location='<?php echo base_url();?>contact'">Contact Us
                        &nbsp;&nbsp; <img src="<?php echo base_url();?>assets/images/a1.svg" class="mt-1 pt-1 explore">
                        <img src="<?php echo base_url();?>assets/images/arrow-1.png" class="explores">
                    </button>
                </div>
            </div>
            <div class="col-lg-2"></div>
        </div>
    </section>
   
   <?php $this->load->view('includes/footer');?>

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/jquery/jquery-migrate.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/superfish/superfish.min.js"></script>

    <script src="js/main.js"></script>

</body>

</html>