<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index_Controller extends CI_Controller
{  
    public function index()
    {
        $this->load->view('index');
    }
    public function contact()
    {
        $this->load->view('contact');
    }
    public function nZeroComingsoon()
    {
        $this->load->view('n-zero-coming-soon');
    }
    public function nKompressComingsoon()
    {
        $this->load->view('n-kompress-coming-soon');
    }
    public function nAdaptComingsoon()
    {
        $this->load->view('n-adapt-coming-soon');
    }
    public function nTrackComingsoon()
    {
        $this->load->view('n-track-coming-soon');
    }
}