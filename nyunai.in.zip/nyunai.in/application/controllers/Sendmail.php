<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sendmail extends CI_Controller
{
    
    public function send_enquiry_email(){
	    extract($_POST);
        if(!empty($name)){   
            $hname=ucfirst($name);
            $message="<p>Dear Admin,</p>";
            $message.="<p>A New enquiry request has been received, and below are the details</p>";
            $message.="<p>Name : $name</p>";
            $message.="<p>Email : $email</p>";
            $message.="<p>Budget : $budget</p>";
            $message.="<p>Service : $interested</p>";
            $message.="<p>Message : $message1</p>";
            $hname=ucfirst($hname);
            if(!empty($hname)){
            $to=["contact@nyunai.com"];
            $body = $message;
            $this->load->library('email');
            //SMTP & mail configuration
            $config = array(
            'protocol'  => 'smtp',
            'smtp_host' => 'smtp.gmail.com',
            'smtp_port' => 465,
            'smtp_user' => 'seshu.richlabz@gmail.com',
            'smtp_pass' => 'fkirfyyyukjgaeux',
            'mailtype'  => 'html',
            'charset'   => 'utf-8',
            'starttls'  => true,
            'newline'   => "\r\n",
            'smtp_crypto'=>'ssl'
            );
            $subject="New Contact Request ".$hname;
            $this->email->initialize($config);
            $this->email->from("seshu.richlabz@gmail.com", $hname);
            $this->email->to($to);
            $this->email->subject($subject);
            $this->email->message($body);
            $result=$this->email->send();
            if($result)
            echo "success";
            else
            echo $this->email->print_debugger();
            }
            else{
            
                echo "Unable to process your request";
            }
        }
        else{
            echo "Invalid captcha code";
        }
	}
}
